/*
  # Alumni-Student Mentorship Platform Schema

  ## Overview
  Creates a complete database schema for connecting students with alumni mentors through
  intelligent matching, messaging, and goal tracking.

  ## New Tables

  ### 1. `profiles`
  User profiles for both students and alumni mentors
  - `id` (uuid, primary key) - References auth.users
  - `email` (text) - User email
  - `full_name` (text) - Full name
  - `user_type` (text) - 'student' or 'mentor'
  - `avatar_url` (text) - Profile picture URL
  - `bio` (text) - User biography
  - `academic_background` (text) - Educational history
  - `career_field` (text) - Career area/industry
  - `skills` (text[]) - Array of skills
  - `interests` (text[]) - Array of interests
  - `linkedin_url` (text) - LinkedIn profile
  - `availability_status` (text) - 'available', 'busy', 'unavailable'
  - `created_at` (timestamptz) - Account creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp

  ### 2. `mentorship_connections`
  Active mentorship relationships between students and mentors
  - `id` (uuid, primary key)
  - `student_id` (uuid) - References profiles(id)
  - `mentor_id` (uuid) - References profiles(id)
  - `status` (text) - 'pending', 'active', 'completed', 'cancelled'
  - `requested_at` (timestamptz) - Connection request timestamp
  - `accepted_at` (timestamptz) - Connection acceptance timestamp
  - `completed_at` (timestamptz) - Connection completion timestamp
  - `created_at` (timestamptz)

  ### 3. `messages`
  Direct messages between mentors and students
  - `id` (uuid, primary key)
  - `connection_id` (uuid) - References mentorship_connections(id)
  - `sender_id` (uuid) - References profiles(id)
  - `content` (text) - Message content
  - `read` (boolean) - Message read status
  - `created_at` (timestamptz)

  ### 4. `discussion_forums`
  Public discussion forums for community interaction
  - `id` (uuid, primary key)
  - `title` (text) - Forum title
  - `description` (text) - Forum description
  - `category` (text) - Forum category
  - `created_by` (uuid) - References profiles(id)
  - `created_at` (timestamptz)

  ### 5. `forum_posts`
  Posts within discussion forums
  - `id` (uuid, primary key)
  - `forum_id` (uuid) - References discussion_forums(id)
  - `author_id` (uuid) - References profiles(id)
  - `content` (text) - Post content
  - `created_at` (timestamptz)

  ### 6. `mentorship_goals`
  Goals set within mentorship relationships
  - `id` (uuid, primary key)
  - `connection_id` (uuid) - References mentorship_connections(id)
  - `title` (text) - Goal title
  - `description` (text) - Goal description
  - `target_date` (date) - Target completion date
  - `status` (text) - 'not_started', 'in_progress', 'completed'
  - `created_by` (uuid) - References profiles(id)
  - `created_at` (timestamptz)
  - `completed_at` (timestamptz)

  ### 7. `goal_milestones`
  Milestones for tracking progress toward goals
  - `id` (uuid, primary key)
  - `goal_id` (uuid) - References mentorship_goals(id)
  - `title` (text) - Milestone title
  - `description` (text) - Milestone description
  - `completed` (boolean) - Completion status
  - `completed_at` (timestamptz)
  - `created_at` (timestamptz)

  ## Security
  - Enable RLS on all tables
  - Policies ensure users can only access their own data or public information
  - Separate policies for students, mentors, and shared access
*/

-- Profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text UNIQUE NOT NULL,
  full_name text NOT NULL,
  user_type text NOT NULL CHECK (user_type IN ('student', 'mentor')),
  avatar_url text,
  bio text,
  academic_background text,
  career_field text,
  skills text[] DEFAULT '{}',
  interests text[] DEFAULT '{}',
  linkedin_url text,
  availability_status text DEFAULT 'available' CHECK (availability_status IN ('available', 'busy', 'unavailable')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Mentorship connections
CREATE TABLE IF NOT EXISTS mentorship_connections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  mentor_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'active', 'completed', 'cancelled')),
  requested_at timestamptz DEFAULT now(),
  accepted_at timestamptz,
  completed_at timestamptz,
  created_at timestamptz DEFAULT now(),
  UNIQUE(student_id, mentor_id)
);

-- Messages
CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  connection_id uuid NOT NULL REFERENCES mentorship_connections(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  content text NOT NULL,
  read boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Discussion forums
CREATE TABLE IF NOT EXISTS discussion_forums (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  category text NOT NULL,
  created_by uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now()
);

-- Forum posts
CREATE TABLE IF NOT EXISTS forum_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  forum_id uuid NOT NULL REFERENCES discussion_forums(id) ON DELETE CASCADE,
  author_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  content text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Mentorship goals
CREATE TABLE IF NOT EXISTS mentorship_goals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  connection_id uuid NOT NULL REFERENCES mentorship_connections(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  target_date date,
  status text DEFAULT 'not_started' CHECK (status IN ('not_started', 'in_progress', 'completed')),
  created_by uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  completed_at timestamptz
);

-- Goal milestones
CREATE TABLE IF NOT EXISTS goal_milestones (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  goal_id uuid NOT NULL REFERENCES mentorship_goals(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text,
  completed boolean DEFAULT false,
  completed_at timestamptz,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE mentorship_connections ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE discussion_forums ENABLE ROW LEVEL SECURITY;
ALTER TABLE forum_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE mentorship_goals ENABLE ROW LEVEL SECURITY;
ALTER TABLE goal_milestones ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Users can view all profiles"
  ON profiles FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Mentorship connections policies
CREATE POLICY "Users can view own connections"
  ON mentorship_connections FOR SELECT
  TO authenticated
  USING (auth.uid() = student_id OR auth.uid() = mentor_id);

CREATE POLICY "Students can create connection requests"
  ON mentorship_connections FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = student_id);

CREATE POLICY "Users can update own connections"
  ON mentorship_connections FOR UPDATE
  TO authenticated
  USING (auth.uid() = student_id OR auth.uid() = mentor_id)
  WITH CHECK (auth.uid() = student_id OR auth.uid() = mentor_id);

-- Messages policies
CREATE POLICY "Users can view messages in their connections"
  ON messages FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM mentorship_connections
      WHERE mentorship_connections.id = messages.connection_id
      AND (mentorship_connections.student_id = auth.uid() OR mentorship_connections.mentor_id = auth.uid())
    )
  );

CREATE POLICY "Users can send messages in their connections"
  ON messages FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = sender_id AND
    EXISTS (
      SELECT 1 FROM mentorship_connections
      WHERE mentorship_connections.id = connection_id
      AND (mentorship_connections.student_id = auth.uid() OR mentorship_connections.mentor_id = auth.uid())
    )
  );

CREATE POLICY "Users can update own messages"
  ON messages FOR UPDATE
  TO authenticated
  USING (sender_id = auth.uid())
  WITH CHECK (sender_id = auth.uid());

-- Discussion forums policies
CREATE POLICY "All users can view forums"
  ON discussion_forums FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can create forums"
  ON discussion_forums FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = created_by);

-- Forum posts policies
CREATE POLICY "All users can view forum posts"
  ON forum_posts FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can create posts"
  ON forum_posts FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Users can update own posts"
  ON forum_posts FOR UPDATE
  TO authenticated
  USING (auth.uid() = author_id)
  WITH CHECK (auth.uid() = author_id);

-- Mentorship goals policies
CREATE POLICY "Users can view goals in their connections"
  ON mentorship_goals FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM mentorship_connections
      WHERE mentorship_connections.id = mentorship_goals.connection_id
      AND (mentorship_connections.student_id = auth.uid() OR mentorship_connections.mentor_id = auth.uid())
    )
  );

CREATE POLICY "Users can create goals in their connections"
  ON mentorship_goals FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = created_by AND
    EXISTS (
      SELECT 1 FROM mentorship_connections
      WHERE mentorship_connections.id = connection_id
      AND (mentorship_connections.student_id = auth.uid() OR mentorship_connections.mentor_id = auth.uid())
    )
  );

CREATE POLICY "Users can update goals in their connections"
  ON mentorship_goals FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM mentorship_connections
      WHERE mentorship_connections.id = mentorship_goals.connection_id
      AND (mentorship_connections.student_id = auth.uid() OR mentorship_connections.mentor_id = auth.uid())
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM mentorship_connections
      WHERE mentorship_connections.id = mentorship_goals.connection_id
      AND (mentorship_connections.student_id = auth.uid() OR mentorship_connections.mentor_id = auth.uid())
    )
  );

-- Goal milestones policies
CREATE POLICY "Users can view milestones in their connections"
  ON goal_milestones FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM mentorship_goals
      JOIN mentorship_connections ON mentorship_connections.id = mentorship_goals.connection_id
      WHERE mentorship_goals.id = goal_milestones.goal_id
      AND (mentorship_connections.student_id = auth.uid() OR mentorship_connections.mentor_id = auth.uid())
    )
  );

CREATE POLICY "Users can create milestones in their connections"
  ON goal_milestones FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM mentorship_goals
      JOIN mentorship_connections ON mentorship_connections.id = mentorship_goals.connection_id
      WHERE mentorship_goals.id = goal_id
      AND (mentorship_connections.student_id = auth.uid() OR mentorship_connections.mentor_id = auth.uid())
    )
  );

CREATE POLICY "Users can update milestones in their connections"
  ON goal_milestones FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM mentorship_goals
      JOIN mentorship_connections ON mentorship_connections.id = mentorship_goals.connection_id
      WHERE mentorship_goals.id = goal_milestones.goal_id
      AND (mentorship_connections.student_id = auth.uid() OR mentorship_connections.mentor_id = auth.uid())
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM mentorship_goals
      JOIN mentorship_connections ON mentorship_connections.id = mentorship_goals.connection_id
      WHERE mentorship_goals.id = goal_milestones.goal_id
      AND (mentorship_connections.student_id = auth.uid() OR mentorship_connections.mentor_id = auth.uid())
    )
  );

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_profiles_user_type ON profiles(user_type);
CREATE INDEX IF NOT EXISTS idx_profiles_availability ON profiles(availability_status);
CREATE INDEX IF NOT EXISTS idx_connections_student ON mentorship_connections(student_id);
CREATE INDEX IF NOT EXISTS idx_connections_mentor ON mentorship_connections(mentor_id);
CREATE INDEX IF NOT EXISTS idx_connections_status ON mentorship_connections(status);
CREATE INDEX IF NOT EXISTS idx_messages_connection ON messages(connection_id);
CREATE INDEX IF NOT EXISTS idx_messages_created ON messages(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_forum_posts_forum ON forum_posts(forum_id);
CREATE INDEX IF NOT EXISTS idx_goals_connection ON mentorship_goals(connection_id);
CREATE INDEX IF NOT EXISTS idx_milestones_goal ON goal_milestones(goal_id);