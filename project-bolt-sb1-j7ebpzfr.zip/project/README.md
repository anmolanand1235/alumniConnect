# MentorConnect - Alumni-Student Mentorship Platform

A comprehensive web-based platform connecting students with alumni mentors through intelligent matching, real-time messaging, goal tracking, and community forums.

## Features

### 1. Smart Mentor-Student Matching
- Advanced filtering by skills, interests, career fields, and academic background
- Intelligent match scoring algorithm
- Real-time mentor availability status
- Detailed mentor profiles with skills and experience

### 2. Connection Management
- Send and receive mentorship requests
- Accept/decline pending connections
- Track active and completed mentorships
- Connection status management

### 3. Real-Time Messaging
- Direct messaging between mentors and students
- Live message updates using Supabase real-time subscriptions
- Read receipts and message history
- Organized conversations by connection

### 4. Goal Setting & Progress Tracking
- Create mentorship goals with descriptions and target dates
- Break goals into trackable milestones
- Visual progress indicators
- Status tracking (not started, in progress, completed)
- Collaborative goal management

### 5. Discussion Forums
- Create topic-based discussion forums
- Post and engage in community conversations
- Categorized forums for easy navigation
- Real-time forum updates

## Technology Stack

- **Frontend**: React 18, TypeScript, Tailwind CSS
- **Backend**: Supabase (PostgreSQL database, Authentication, Real-time subscriptions)
- **Icons**: Lucide React
- **Build Tool**: Vite

## Database Schema

The platform uses the following main tables:
- `profiles` - User profiles for students and mentors
- `mentorship_connections` - Active mentorship relationships
- `messages` - Direct messages between users
- `discussion_forums` - Community forums
- `forum_posts` - Forum discussions
- `mentorship_goals` - Goal definitions
- `goal_milestones` - Milestone tracking

All tables have Row Level Security (RLS) enabled for data protection.

## Getting Started

1. The Supabase database is already configured with all necessary tables and security policies

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Create an account:
   - Choose between Student or Mentor account type
   - Fill in your profile with skills, interests, and career field
   - Complete your bio and academic background

## User Flows

### For Students:
1. Sign up and complete your profile
2. Browse the "Discover Mentors" tab to find alumni with matching interests
3. Send mentorship requests to mentors you'd like to connect with
4. Once accepted, communicate via Messages
5. Set goals together and track progress
6. Participate in community forums

### For Mentors:
1. Sign up as a mentor and showcase your expertise
2. Review incoming mentorship requests in the Connections tab
3. Accept requests from students you can help
4. Message students and provide guidance
5. Collaborate on goal setting and milestone tracking
6. Share knowledge in forums

## Key Components

- `Auth.tsx` - Authentication interface with sign up/sign in forms
- `Dashboard.tsx` - Main application dashboard with tab navigation
- `MentorList.tsx` - Mentor discovery and matching interface
- `Connections.tsx` - Connection management and status tracking
- `Messages.tsx` - Real-time messaging interface
- `Goals.tsx` - Goal and milestone tracking system
- `Forums.tsx` - Community discussion forums

## Security

- All database access is protected by Row Level Security policies
- Users can only access their own data and connections
- Authentication required for all features
- Secure password handling via Supabase Auth

## Future Enhancements

- Video call integration
- Calendar scheduling for mentorship sessions
- Resource sharing and file uploads
- Analytics dashboard for tracking mentorship impact
- Mobile app version
- Email notifications
- Advanced search with filters
- Mentor ratings and reviews

## License

MIT
