import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Profile = {
  id: string;
  email: string;
  full_name: string;
  user_type: 'student' | 'mentor';
  avatar_url?: string;
  bio?: string;
  academic_background?: string;
  career_field?: string;
  skills: string[];
  interests: string[];
  linkedin_url?: string;
  availability_status: 'available' | 'busy' | 'unavailable';
  created_at: string;
  updated_at: string;
};

export type MentorshipConnection = {
  id: string;
  student_id: string;
  mentor_id: string;
  status: 'pending' | 'active' | 'completed' | 'cancelled';
  requested_at: string;
  accepted_at?: string;
  completed_at?: string;
  created_at: string;
};

export type Message = {
  id: string;
  connection_id: string;
  sender_id: string;
  content: string;
  read: boolean;
  created_at: string;
};

export type MentorshipGoal = {
  id: string;
  connection_id: string;
  title: string;
  description?: string;
  target_date?: string;
  status: 'not_started' | 'in_progress' | 'completed';
  created_by: string;
  created_at: string;
  completed_at?: string;
};

export type GoalMilestone = {
  id: string;
  goal_id: string;
  title: string;
  description?: string;
  completed: boolean;
  completed_at?: string;
  created_at: string;
};
