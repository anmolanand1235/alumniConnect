import { useState, useEffect } from 'react';
import { supabase, MentorshipGoal, GoalMilestone, Profile } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { Target, Plus, CheckCircle2, Circle, Calendar, Trash2 } from 'lucide-react';

type GoalWithMilestones = MentorshipGoal & {
  milestones?: GoalMilestone[];
};

type ConnectionWithProfiles = {
  id: string;
  student: Profile;
  mentor: Profile;
};

export const Goals = () => {
  const { profile } = useAuth();
  const [connections, setConnections] = useState<ConnectionWithProfiles[]>([]);
  const [selectedConnection, setSelectedConnection] = useState<string | null>(null);
  const [goals, setGoals] = useState<GoalWithMilestones[]>([]);
  const [showNewGoalForm, setShowNewGoalForm] = useState(false);
  const [showNewMilestoneForm, setShowNewMilestoneForm] = useState<string | null>(null);
  const [newGoal, setNewGoal] = useState({ title: '', description: '', target_date: '' });
  const [newMilestone, setNewMilestone] = useState({ title: '', description: '' });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchConnections();
  }, [profile]);

  useEffect(() => {
    if (selectedConnection) {
      fetchGoals();
    }
  }, [selectedConnection]);

  const fetchConnections = async () => {
    if (!profile) return;

    try {
      const { data, error } = await supabase
        .from('mentorship_connections')
        .select(`
          id,
          student:profiles!mentorship_connections_student_id_fkey(*),
          mentor:profiles!mentorship_connections_mentor_id_fkey(*)
        `)
        .eq('status', 'active')
        .or(`student_id.eq.${profile.id},mentor_id.eq.${profile.id}`);

      if (error) throw error;
      setConnections(data || []);
      if (data && data.length > 0 && !selectedConnection) {
        setSelectedConnection(data[0].id);
      }
    } catch (error) {
      console.error('Error fetching connections:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchGoals = async () => {
    if (!selectedConnection) return;

    try {
      const { data, error } = await supabase
        .from('mentorship_goals')
        .select(`
          *,
          milestones:goal_milestones(*)
        `)
        .eq('connection_id', selectedConnection)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setGoals(data || []);
    } catch (error) {
      console.error('Error fetching goals:', error);
    }
  };

  const createGoal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedConnection || !profile) return;

    try {
      const { error } = await supabase.from('mentorship_goals').insert({
        connection_id: selectedConnection,
        title: newGoal.title,
        description: newGoal.description,
        target_date: newGoal.target_date || null,
        created_by: profile.id,
      });

      if (error) throw error;
      setNewGoal({ title: '', description: '', target_date: '' });
      setShowNewGoalForm(false);
      fetchGoals();
    } catch (error) {
      console.error('Error creating goal:', error);
    }
  };

  const updateGoalStatus = async (goalId: string, status: string) => {
    try {
      const updateData: Record<string, unknown> = { status };
      if (status === 'completed') {
        updateData.completed_at = new Date().toISOString();
      }

      const { error } = await supabase
        .from('mentorship_goals')
        .update(updateData)
        .eq('id', goalId);

      if (error) throw error;
      fetchGoals();
    } catch (error) {
      console.error('Error updating goal:', error);
    }
  };

  const createMilestone = async (goalId: string, e: React.FormEvent) => {
    e.preventDefault();

    try {
      const { error } = await supabase.from('goal_milestones').insert({
        goal_id: goalId,
        title: newMilestone.title,
        description: newMilestone.description,
      });

      if (error) throw error;
      setNewMilestone({ title: '', description: '' });
      setShowNewMilestoneForm(null);
      fetchGoals();
    } catch (error) {
      console.error('Error creating milestone:', error);
    }
  };

  const toggleMilestone = async (milestoneId: string, completed: boolean) => {
    try {
      const updateData: Record<string, unknown> = { completed };
      if (completed) {
        updateData.completed_at = new Date().toISOString();
      } else {
        updateData.completed_at = null;
      }

      const { error } = await supabase
        .from('goal_milestones')
        .update(updateData)
        .eq('id', milestoneId);

      if (error) throw error;
      fetchGoals();
    } catch (error) {
      console.error('Error toggling milestone:', error);
    }
  };

  const deleteGoal = async (goalId: string) => {
    if (!confirm('Are you sure you want to delete this goal?')) return;

    try {
      const { error } = await supabase
        .from('mentorship_goals')
        .delete()
        .eq('id', goalId);

      if (error) throw error;
      fetchGoals();
    } catch (error) {
      console.error('Error deleting goal:', error);
    }
  };

  const getOtherUser = (connection: ConnectionWithProfiles): Profile => {
    return profile?.user_type === 'student' ? connection.mentor : connection.student;
  };

  const getStatusColor = (status: string) => {
    const colors = {
      not_started: 'bg-gray-100 text-gray-700',
      in_progress: 'bg-blue-100 text-blue-700',
      completed: 'bg-green-100 text-green-700',
    };
    return colors[status as keyof typeof colors] || colors.not_started;
  };

  if (loading) {
    return <div className="text-center py-12 text-gray-600">Loading goals...</div>;
  }

  if (connections.length === 0) {
    return (
      <div className="text-center py-12">
        <Target className="w-16 h-16 text-gray-400 mx-auto mb-4" />
        <p className="text-gray-600">No active connections yet. Connect with mentors to start setting goals!</p>
      </div>
    );
  }

  const currentConnection = connections.find(c => c.id === selectedConnection);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Goals & Progress Tracking</h2>
        <p className="text-gray-600">Set objectives and track milestones with your mentor</p>
      </div>

      <div className="flex gap-4 overflow-x-auto pb-2">
        {connections.map((connection) => {
          const otherUser = getOtherUser(connection);
          return (
            <button
              key={connection.id}
              onClick={() => setSelectedConnection(connection.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium whitespace-nowrap transition ${
                selectedConnection === connection.id
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-green-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                {otherUser.full_name.charAt(0)}
              </div>
              {otherUser.full_name}
            </button>
          );
        })}
      </div>

      {currentConnection && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-gray-900">
              Goals with {getOtherUser(currentConnection).full_name}
            </h3>
            <button
              onClick={() => setShowNewGoalForm(!showNewGoalForm)}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition"
            >
              <Plus className="w-5 h-5" />
              New Goal
            </button>
          </div>

          {showNewGoalForm && (
            <form onSubmit={createGoal} className="bg-blue-50 border border-blue-200 rounded-xl p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Goal Title</label>
                <input
                  type="text"
                  value={newGoal.title}
                  onChange={(e) => setNewGoal({ ...newGoal, title: e.target.value })}
                  required
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                  placeholder="e.g., Learn React.js"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea
                  value={newGoal.description}
                  onChange={(e) => setNewGoal({ ...newGoal, description: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none resize-none"
                  rows={3}
                  placeholder="Describe the goal..."
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Target Date (Optional)</label>
                <input
                  type="date"
                  value={newGoal.target_date}
                  onChange={(e) => setNewGoal({ ...newGoal, target_date: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                />
              </div>
              <div className="flex gap-2">
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition"
                >
                  Create Goal
                </button>
                <button
                  type="button"
                  onClick={() => setShowNewGoalForm(false)}
                  className="px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded-lg font-medium transition"
                >
                  Cancel
                </button>
              </div>
            </form>
          )}

          {goals.length === 0 ? (
            <div className="text-center py-12 bg-gray-50 rounded-xl">
              <Target className="w-12 h-12 text-gray-400 mx-auto mb-3" />
              <p className="text-gray-600">No goals yet. Create your first goal to start tracking progress!</p>
            </div>
          ) : (
            <div className="space-y-4">
              {goals.map((goal) => {
                const completedMilestones = goal.milestones?.filter(m => m.completed).length || 0;
                const totalMilestones = goal.milestones?.length || 0;
                const progress = totalMilestones > 0 ? (completedMilestones / totalMilestones) * 100 : 0;

                return (
                  <div key={goal.id} className="bg-white border border-gray-200 rounded-xl p-6 space-y-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-start gap-3 mb-2">
                          <Target className="w-6 h-6 text-blue-600 flex-shrink-0 mt-1" />
                          <div className="flex-1">
                            <h4 className="text-lg font-semibold text-gray-900">{goal.title}</h4>
                            {goal.description && (
                              <p className="text-gray-600 mt-1">{goal.description}</p>
                            )}
                          </div>
                        </div>
                        <div className="flex flex-wrap items-center gap-3 mt-3">
                          <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(goal.status)}`}>
                            {goal.status.replace('_', ' ').charAt(0).toUpperCase() + goal.status.slice(1).replace('_', ' ')}
                          </span>
                          {goal.target_date && (
                            <span className="flex items-center gap-1 text-sm text-gray-600">
                              <Calendar className="w-4 h-4" />
                              Target: {new Date(goal.target_date).toLocaleDateString()}
                            </span>
                          )}
                          {totalMilestones > 0 && (
                            <span className="text-sm text-gray-600">
                              Progress: {completedMilestones}/{totalMilestones} milestones
                            </span>
                          )}
                        </div>
                      </div>
                      <button
                        onClick={() => deleteGoal(goal.id)}
                        className="text-red-600 hover:text-red-700 p-2"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>

                    {totalMilestones > 0 && (
                      <div>
                        <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
                          <div
                            className="bg-blue-600 h-2 rounded-full transition-all"
                            style={{ width: `${progress}%` }}
                          />
                        </div>
                      </div>
                    )}

                    <div className="flex gap-2">
                      {goal.status !== 'completed' && (
                        <>
                          {goal.status === 'not_started' && (
                            <button
                              onClick={() => updateGoalStatus(goal.id, 'in_progress')}
                              className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg transition"
                            >
                              Start Goal
                            </button>
                          )}
                          {goal.status === 'in_progress' && (
                            <button
                              onClick={() => updateGoalStatus(goal.id, 'completed')}
                              className="px-3 py-1 bg-green-600 hover:bg-green-700 text-white text-sm rounded-lg transition"
                            >
                              Mark Complete
                            </button>
                          )}
                        </>
                      )}
                    </div>

                    <div className="border-t border-gray-200 pt-4">
                      <div className="flex items-center justify-between mb-3">
                        <h5 className="font-medium text-gray-900">Milestones</h5>
                        <button
                          onClick={() => setShowNewMilestoneForm(showNewMilestoneForm === goal.id ? null : goal.id)}
                          className="flex items-center gap-1 px-3 py-1 text-sm bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg transition"
                        >
                          <Plus className="w-4 h-4" />
                          Add Milestone
                        </button>
                      </div>

                      {showNewMilestoneForm === goal.id && (
                        <form onSubmit={(e) => createMilestone(goal.id, e)} className="bg-gray-50 rounded-lg p-4 mb-3 space-y-3">
                          <input
                            type="text"
                            value={newMilestone.title}
                            onChange={(e) => setNewMilestone({ ...newMilestone, title: e.target.value })}
                            required
                            className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                            placeholder="Milestone title"
                          />
                          <input
                            type="text"
                            value={newMilestone.description}
                            onChange={(e) => setNewMilestone({ ...newMilestone, description: e.target.value })}
                            className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                            placeholder="Description (optional)"
                          />
                          <div className="flex gap-2">
                            <button type="submit" className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg transition">
                              Add
                            </button>
                            <button
                              type="button"
                              onClick={() => setShowNewMilestoneForm(null)}
                              className="px-3 py-1 bg-gray-200 hover:bg-gray-300 text-gray-800 text-sm rounded-lg transition"
                            >
                              Cancel
                            </button>
                          </div>
                        </form>
                      )}

                      <div className="space-y-2">
                        {goal.milestones && goal.milestones.length > 0 ? (
                          goal.milestones.map((milestone) => (
                            <div
                              key={milestone.id}
                              className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition"
                            >
                              <button
                                onClick={() => toggleMilestone(milestone.id, !milestone.completed)}
                                className="flex-shrink-0 mt-0.5"
                              >
                                {milestone.completed ? (
                                  <CheckCircle2 className="w-5 h-5 text-green-600" />
                                ) : (
                                  <Circle className="w-5 h-5 text-gray-400" />
                                )}
                              </button>
                              <div className="flex-1">
                                <p className={`text-sm ${milestone.completed ? 'text-gray-500 line-through' : 'text-gray-900'}`}>
                                  {milestone.title}
                                </p>
                                {milestone.description && (
                                  <p className="text-xs text-gray-600 mt-1">{milestone.description}</p>
                                )}
                              </div>
                            </div>
                          ))
                        ) : (
                          <p className="text-sm text-gray-500 py-2">No milestones yet. Add your first milestone above!</p>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
