import { useState, useEffect } from 'react';
import { supabase, Profile } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { MessageSquare, Plus, Send, Users } from 'lucide-react';

type Forum = {
  id: string;
  title: string;
  description: string;
  category: string;
  created_by: string;
  created_at: string;
  creator?: Profile;
};

type ForumPost = {
  id: string;
  forum_id: string;
  author_id: string;
  content: string;
  created_at: string;
  author?: Profile;
};

export const Forums = () => {
  const { profile } = useAuth();
  const [forums, setForums] = useState<Forum[]>([]);
  const [selectedForum, setSelectedForum] = useState<string | null>(null);
  const [posts, setPosts] = useState<ForumPost[]>([]);
  const [showNewForumForm, setShowNewForumForm] = useState(false);
  const [newForum, setNewForum] = useState({ title: '', description: '', category: 'General' });
  const [newPost, setNewPost] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchForums();
  }, []);

  useEffect(() => {
    if (selectedForum) {
      fetchPosts();
      const subscription = supabase
        .channel(`forum_posts:${selectedForum}`)
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'forum_posts',
            filter: `forum_id=eq.${selectedForum}`,
          },
          () => {
            fetchPosts();
          }
        )
        .subscribe();

      return () => {
        subscription.unsubscribe();
      };
    }
  }, [selectedForum]);

  const fetchForums = async () => {
    try {
      const { data, error } = await supabase
        .from('discussion_forums')
        .select(`
          *,
          creator:profiles(*)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setForums(data || []);
      if (data && data.length > 0 && !selectedForum) {
        setSelectedForum(data[0].id);
      }
    } catch (error) {
      console.error('Error fetching forums:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchPosts = async () => {
    if (!selectedForum) return;

    try {
      const { data, error } = await supabase
        .from('forum_posts')
        .select(`
          *,
          author:profiles(*)
        `)
        .eq('forum_id', selectedForum)
        .order('created_at', { ascending: true });

      if (error) throw error;
      setPosts(data || []);
    } catch (error) {
      console.error('Error fetching posts:', error);
    }
  };

  const createForum = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;

    try {
      const { data, error } = await supabase
        .from('discussion_forums')
        .insert({
          title: newForum.title,
          description: newForum.description,
          category: newForum.category,
          created_by: profile.id,
        })
        .select()
        .single();

      if (error) throw error;
      setNewForum({ title: '', description: '', category: 'General' });
      setShowNewForumForm(false);
      fetchForums();
      if (data) {
        setSelectedForum(data.id);
      }
    } catch (error) {
      console.error('Error creating forum:', error);
    }
  };

  const createPost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPost.trim() || !selectedForum || !profile) return;

    try {
      const { error } = await supabase.from('forum_posts').insert({
        forum_id: selectedForum,
        author_id: profile.id,
        content: newPost.trim(),
      });

      if (error) throw error;
      setNewPost('');
    } catch (error) {
      console.error('Error creating post:', error);
    }
  };

  const categories = ['General', 'Career Advice', 'Academic', 'Networking', 'Industry Insights', 'Other'];

  if (loading) {
    return <div className="text-center py-12 text-gray-600">Loading forums...</div>;
  }

  const currentForum = forums.find(f => f.id === selectedForum);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Discussion Forums</h2>
          <p className="text-gray-600">Connect with the community and share knowledge</p>
        </div>
        <button
          onClick={() => setShowNewForumForm(!showNewForumForm)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition"
        >
          <Plus className="w-5 h-5" />
          New Forum
        </button>
      </div>

      {showNewForumForm && (
        <form onSubmit={createForum} className="bg-blue-50 border border-blue-200 rounded-xl p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Forum Title</label>
            <input
              type="text"
              value={newForum.title}
              onChange={(e) => setNewForum({ ...newForum, title: e.target.value })}
              required
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
              placeholder="e.g., Software Engineering Career Paths"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
            <textarea
              value={newForum.description}
              onChange={(e) => setNewForum({ ...newForum, description: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none resize-none"
              rows={3}
              placeholder="Describe the forum topic..."
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
            <select
              value={newForum.category}
              onChange={(e) => setNewForum({ ...newForum, category: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
            >
              {categories.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>
          <div className="flex gap-2">
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition"
            >
              Create Forum
            </button>
            <button
              type="button"
              onClick={() => setShowNewForumForm(false)}
              className="px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-800 rounded-lg font-medium transition"
            >
              Cancel
            </button>
          </div>
        </form>
      )}

      {forums.length === 0 ? (
        <div className="text-center py-12 bg-gray-50 rounded-xl">
          <MessageSquare className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600">No forums yet. Create the first one!</p>
        </div>
      ) : (
        <div className="grid md:grid-cols-3 gap-4">
          <div className="md:col-span-1 space-y-2">
            <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
              <Users className="w-5 h-5" />
              Forums
            </h3>
            <div className="space-y-2">
              {forums.map((forum) => (
                <button
                  key={forum.id}
                  onClick={() => setSelectedForum(forum.id)}
                  className={`w-full text-left p-4 rounded-xl transition ${
                    selectedForum === forum.id
                      ? 'bg-blue-600 text-white'
                      : 'bg-white border border-gray-200 hover:shadow-md'
                  }`}
                >
                  <h4 className={`font-semibold mb-1 ${selectedForum === forum.id ? 'text-white' : 'text-gray-900'}`}>
                    {forum.title}
                  </h4>
                  <p className={`text-xs ${selectedForum === forum.id ? 'text-blue-100' : 'text-gray-600'}`}>
                    {forum.category}
                  </p>
                </button>
              ))}
            </div>
          </div>

          <div className="md:col-span-2">
            {currentForum && (
              <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
                <div className="p-6 border-b border-gray-200">
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{currentForum.title}</h3>
                  {currentForum.description && (
                    <p className="text-gray-600 mb-3">{currentForum.description}</p>
                  )}
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-medium">
                      {currentForum.category}
                    </span>
                    <span>•</span>
                    <span>Created by {currentForum.creator?.full_name}</span>
                  </div>
                </div>

                <div className="h-[400px] overflow-y-auto p-6 space-y-4 bg-gray-50">
                  {posts.length === 0 ? (
                    <div className="text-center py-8 text-gray-600">
                      <MessageSquare className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                      <p>No posts yet. Start the conversation!</p>
                    </div>
                  ) : (
                    posts.map((post) => (
                      <div key={post.id} className="bg-white rounded-lg p-4 shadow-sm">
                        <div className="flex items-start gap-3">
                          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-green-500 rounded-full flex items-center justify-center text-white font-bold flex-shrink-0">
                            {post.author?.full_name.charAt(0)}
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-semibold text-gray-900">{post.author?.full_name}</span>
                              <span className="text-xs text-gray-500">
                                {new Date(post.created_at).toLocaleString()}
                              </span>
                            </div>
                            <p className="text-gray-700 whitespace-pre-wrap">{post.content}</p>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>

                <form onSubmit={createPost} className="p-4 border-t border-gray-200 bg-white">
                  <div className="flex gap-2">
                    <textarea
                      value={newPost}
                      onChange={(e) => setNewPost(e.target.value)}
                      placeholder="Share your thoughts..."
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none resize-none"
                      rows={2}
                    />
                    <button
                      type="submit"
                      disabled={!newPost.trim()}
                      className="bg-blue-600 hover:bg-blue-700 text-white px-4 rounded-lg transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                    >
                      <Send className="w-5 h-5" />
                    </button>
                  </div>
                </form>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
