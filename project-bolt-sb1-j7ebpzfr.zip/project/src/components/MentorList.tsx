import { useState, useEffect } from 'react';
import { supabase, Profile } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { UserPlus, Briefcase, Award, Heart, Search } from 'lucide-react';

export const MentorList = () => {
  const { profile } = useAuth();
  const [mentors, setMentors] = useState<Profile[]>([]);
  const [filteredMentors, setFilteredMentors] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterField, setFilterField] = useState<string>('all');

  useEffect(() => {
    fetchMentors();
  }, []);

  useEffect(() => {
    filterMentors();
  }, [searchTerm, filterField, mentors]);

  const fetchMentors = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_type', 'mentor')
        .eq('availability_status', 'available')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setMentors(data || []);
      setFilteredMentors(data || []);
    } catch (error) {
      console.error('Error fetching mentors:', error);
    } finally {
      setLoading(false);
    }
  };

  const filterMentors = () => {
    let filtered = mentors;

    if (searchTerm) {
      filtered = filtered.filter(
        (mentor) =>
          mentor.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          mentor.bio?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          mentor.career_field?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          mentor.skills.some(skill => skill.toLowerCase().includes(searchTerm.toLowerCase())) ||
          mentor.interests.some(interest => interest.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    if (filterField !== 'all' && profile) {
      filtered = filtered.filter((mentor) => {
        if (filterField === 'skills') {
          return mentor.skills.some(skill => profile.skills.includes(skill));
        } else if (filterField === 'interests') {
          return mentor.interests.some(interest => profile.interests.includes(interest));
        } else if (filterField === 'career') {
          return mentor.career_field === profile.career_field;
        }
        return true;
      });
    }

    setFilteredMentors(filtered);
  };

  const requestMentorship = async (mentorId: string) => {
    if (!profile) return;

    try {
      const { error } = await supabase.from('mentorship_connections').insert({
        student_id: profile.id,
        mentor_id: mentorId,
        status: 'pending',
      });

      if (error) throw error;
      alert('Mentorship request sent successfully!');
      fetchMentors();
    } catch (error) {
      console.error('Error requesting mentorship:', error);
      alert('Failed to send mentorship request. You may have already requested this mentor.');
    }
  };

  const calculateMatchScore = (mentor: Profile): number => {
    if (!profile) return 0;

    let score = 0;
    const skillsMatch = mentor.skills.filter(skill => profile.skills.includes(skill)).length;
    const interestsMatch = mentor.interests.filter(interest => profile.interests.includes(interest)).length;
    const careerMatch = mentor.career_field === profile.career_field ? 1 : 0;

    score = (skillsMatch * 2) + (interestsMatch * 1.5) + (careerMatch * 3);
    return Math.min(score, 10);
  };

  if (loading) {
    return <div className="text-center py-12 text-gray-600">Loading mentors...</div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Discover Mentors</h2>
        <p className="text-gray-600 mb-6">Find alumni mentors who match your interests and goals</p>

        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search by name, skills, interests, or career field..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
            />
          </div>
          <select
            value={filterField}
            onChange={(e) => setFilterField(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
          >
            <option value="all">All Mentors</option>
            <option value="skills">Matching Skills</option>
            <option value="interests">Matching Interests</option>
            <option value="career">Same Career Field</option>
          </select>
        </div>
      </div>

      {filteredMentors.length === 0 ? (
        <div className="text-center py-12 text-gray-600">
          No mentors found matching your criteria.
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2">
          {filteredMentors.map((mentor) => {
            const matchScore = calculateMatchScore(mentor);
            return (
              <div
                key={mentor.id}
                className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-lg transition"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-start gap-4">
                    <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-green-500 rounded-full flex items-center justify-center text-white text-xl font-bold">
                      {mentor.full_name.charAt(0)}
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900">{mentor.full_name}</h3>
                      {mentor.career_field && (
                        <p className="text-sm text-gray-600 flex items-center gap-1 mt-1">
                          <Briefcase className="w-4 h-4" />
                          {mentor.career_field}
                        </p>
                      )}
                    </div>
                  </div>
                  {matchScore > 0 && (
                    <div className="flex items-center gap-1 bg-green-50 text-green-700 px-3 py-1 rounded-full text-sm font-medium">
                      <Heart className="w-4 h-4 fill-current" />
                      {matchScore.toFixed(1)}
                    </div>
                  )}
                </div>

                {mentor.bio && (
                  <p className="text-gray-700 mb-4 line-clamp-3">{mentor.bio}</p>
                )}

                {mentor.academic_background && (
                  <div className="mb-3">
                    <p className="text-sm text-gray-600 flex items-center gap-1">
                      <Award className="w-4 h-4" />
                      {mentor.academic_background}
                    </p>
                  </div>
                )}

                {mentor.skills.length > 0 && (
                  <div className="mb-3">
                    <p className="text-sm font-medium text-gray-700 mb-2">Skills:</p>
                    <div className="flex flex-wrap gap-2">
                      {mentor.skills.slice(0, 5).map((skill, idx) => (
                        <span
                          key={idx}
                          className="px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-xs font-medium"
                        >
                          {skill}
                        </span>
                      ))}
                      {mentor.skills.length > 5 && (
                        <span className="px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-xs">
                          +{mentor.skills.length - 5} more
                        </span>
                      )}
                    </div>
                  </div>
                )}

                {mentor.interests.length > 0 && (
                  <div className="mb-4">
                    <p className="text-sm font-medium text-gray-700 mb-2">Interests:</p>
                    <div className="flex flex-wrap gap-2">
                      {mentor.interests.slice(0, 5).map((interest, idx) => (
                        <span
                          key={idx}
                          className="px-3 py-1 bg-green-50 text-green-700 rounded-full text-xs font-medium"
                        >
                          {interest}
                        </span>
                      ))}
                      {mentor.interests.length > 5 && (
                        <span className="px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-xs">
                          +{mentor.interests.length - 5} more
                        </span>
                      )}
                    </div>
                  </div>
                )}

                <button
                  onClick={() => requestMentorship(mentor.id)}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 rounded-lg transition flex items-center justify-center gap-2"
                >
                  <UserPlus className="w-5 h-5" />
                  Request Mentorship
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
