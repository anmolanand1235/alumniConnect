import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { MentorList } from './MentorList';
import { Connections } from './Connections';
import { Messages } from './Messages';
import { Goals } from './Goals';
import { Forums } from './Forums';
import { LogOut, Users, MessageCircle, Target, BookOpen, Search } from 'lucide-react';

type Tab = 'discover' | 'connections' | 'messages' | 'goals' | 'forums';

export const Dashboard = () => {
  const { profile, signOut } = useAuth();
  const [activeTab, setActiveTab] = useState<Tab>('discover');

  const tabs = [
    { id: 'discover' as Tab, label: 'Discover Mentors', icon: Search, studentOnly: true },
    { id: 'connections' as Tab, label: 'Connections', icon: Users, studentOnly: false },
    { id: 'messages' as Tab, label: 'Messages', icon: MessageCircle, studentOnly: false },
    { id: 'goals' as Tab, label: 'Goals & Progress', icon: Target, studentOnly: false },
    { id: 'forums' as Tab, label: 'Forums', icon: BookOpen, studentOnly: false },
  ];

  const filteredTabs = profile?.user_type === 'student'
    ? tabs
    : tabs.filter(tab => !tab.studentOnly);

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">MentorConnect</h1>
              <p className="text-sm text-gray-600">
                Welcome back, {profile?.full_name} ({profile?.user_type})
              </p>
            </div>
            <button
              onClick={signOut}
              className="flex items-center gap-2 px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition"
            >
              <LogOut className="w-5 h-5" />
              Sign Out
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <div className="border-b border-gray-200">
            <nav className="flex overflow-x-auto">
              {filteredTabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center gap-2 px-6 py-4 font-medium transition whitespace-nowrap ${
                      activeTab === tab.id
                        ? 'text-blue-600 border-b-2 border-blue-600'
                        : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    {tab.label}
                  </button>
                );
              })}
            </nav>
          </div>

          <div className="p-6">
            {activeTab === 'discover' && <MentorList />}
            {activeTab === 'connections' && <Connections />}
            {activeTab === 'messages' && <Messages />}
            {activeTab === 'goals' && <Goals />}
            {activeTab === 'forums' && <Forums />}
          </div>
        </div>
      </div>
    </div>
  );
};
