import { useState, useEffect } from 'react';
import { supabase, MentorshipConnection, Profile } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { Check, X, Clock, UserCheck, Star } from 'lucide-react';

type ConnectionWithProfile = MentorshipConnection & {
  student?: Profile;
  mentor?: Profile;
};

export const Connections = () => {
  const { profile } = useAuth();
  const [connections, setConnections] = useState<ConnectionWithProfile[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchConnections();
  }, [profile]);

  const fetchConnections = async () => {
    if (!profile) return;

    try {
      const { data, error } = await supabase
        .from('mentorship_connections')
        .select(`
          *,
          student:profiles!mentorship_connections_student_id_fkey(*),
          mentor:profiles!mentorship_connections_mentor_id_fkey(*)
        `)
        .or(`student_id.eq.${profile.id},mentor_id.eq.${profile.id}`)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setConnections(data || []);
    } catch (error) {
      console.error('Error fetching connections:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateConnectionStatus = async (connectionId: string, status: string) => {
    try {
      const updateData: Record<string, unknown> = { status };
      if (status === 'active') {
        updateData.accepted_at = new Date().toISOString();
      } else if (status === 'completed') {
        updateData.completed_at = new Date().toISOString();
      }

      const { error } = await supabase
        .from('mentorship_connections')
        .update(updateData)
        .eq('id', connectionId);

      if (error) throw error;
      fetchConnections();
    } catch (error) {
      console.error('Error updating connection:', error);
    }
  };

  const getStatusBadge = (status: string) => {
    const styles = {
      pending: 'bg-yellow-50 text-yellow-700 border-yellow-200',
      active: 'bg-green-50 text-green-700 border-green-200',
      completed: 'bg-blue-50 text-blue-700 border-blue-200',
      cancelled: 'bg-gray-50 text-gray-700 border-gray-200',
    };

    const icons = {
      pending: Clock,
      active: UserCheck,
      completed: Star,
      cancelled: X,
    };

    const Icon = icons[status as keyof typeof icons];
    const style = styles[status as keyof typeof styles];

    return (
      <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-sm font-medium border ${style}`}>
        <Icon className="w-4 h-4" />
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </span>
    );
  };

  if (loading) {
    return <div className="text-center py-12 text-gray-600">Loading connections...</div>;
  }

  const pendingConnections = connections.filter(c => c.status === 'pending');
  const activeConnections = connections.filter(c => c.status === 'active');
  const otherConnections = connections.filter(c => c.status !== 'pending' && c.status !== 'active');

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">My Connections</h2>
        <p className="text-gray-600">Manage your mentorship relationships</p>
      </div>

      {pendingConnections.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <Clock className="w-5 h-5 text-yellow-600" />
            Pending Requests ({pendingConnections.length})
          </h3>
          <div className="space-y-4">
            {pendingConnections.map((connection) => {
              const otherUser = profile?.user_type === 'student' ? connection.mentor : connection.student;
              const isMentor = profile?.user_type === 'mentor';

              return (
                <div
                  key={connection.id}
                  className="bg-yellow-50 border border-yellow-200 rounded-xl p-6"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-green-500 rounded-full flex items-center justify-center text-white font-bold">
                        {otherUser?.full_name.charAt(0)}
                      </div>
                      <div>
                        <h4 className="text-lg font-semibold text-gray-900">{otherUser?.full_name}</h4>
                        <p className="text-sm text-gray-600">{otherUser?.career_field}</p>
                      </div>
                    </div>
                    {getStatusBadge(connection.status)}
                  </div>

                  {isMentor && (
                    <div className="flex gap-3">
                      <button
                        onClick={() => updateConnectionStatus(connection.id, 'active')}
                        className="flex-1 bg-green-600 hover:bg-green-700 text-white font-medium py-2 rounded-lg transition flex items-center justify-center gap-2"
                      >
                        <Check className="w-5 h-5" />
                        Accept
                      </button>
                      <button
                        onClick={() => updateConnectionStatus(connection.id, 'cancelled')}
                        className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium py-2 rounded-lg transition flex items-center justify-center gap-2"
                      >
                        <X className="w-5 h-5" />
                        Decline
                      </button>
                    </div>
                  )}

                  {!isMentor && (
                    <div className="text-sm text-gray-600">
                      Waiting for mentor to respond...
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {activeConnections.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <UserCheck className="w-5 h-5 text-green-600" />
            Active Mentorships ({activeConnections.length})
          </h3>
          <div className="grid gap-4 md:grid-cols-2">
            {activeConnections.map((connection) => {
              const otherUser = profile?.user_type === 'student' ? connection.mentor : connection.student;

              return (
                <div
                  key={connection.id}
                  className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-md transition"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-green-500 rounded-full flex items-center justify-center text-white font-bold">
                        {otherUser?.full_name.charAt(0)}
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">{otherUser?.full_name}</h4>
                        <p className="text-sm text-gray-600">{otherUser?.career_field}</p>
                      </div>
                    </div>
                    {getStatusBadge(connection.status)}
                  </div>

                  {otherUser?.bio && (
                    <p className="text-sm text-gray-700 mb-4 line-clamp-2">{otherUser.bio}</p>
                  )}

                  <div className="flex gap-2">
                    <button
                      onClick={() => updateConnectionStatus(connection.id, 'completed')}
                      className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 text-sm rounded-lg transition"
                    >
                      Mark Complete
                    </button>
                    <button
                      onClick={() => updateConnectionStatus(connection.id, 'cancelled')}
                      className="px-4 bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium py-2 text-sm rounded-lg transition"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {otherConnections.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Past Connections</h3>
          <div className="grid gap-4 md:grid-cols-2">
            {otherConnections.map((connection) => {
              const otherUser = profile?.user_type === 'student' ? connection.mentor : connection.student;

              return (
                <div
                  key={connection.id}
                  className="bg-white border border-gray-200 rounded-xl p-6"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center text-gray-600 font-bold">
                        {otherUser?.full_name.charAt(0)}
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">{otherUser?.full_name}</h4>
                        <p className="text-sm text-gray-600">{otherUser?.career_field}</p>
                      </div>
                    </div>
                    {getStatusBadge(connection.status)}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {connections.length === 0 && (
        <div className="text-center py-12 text-gray-600">
          No connections yet. {profile?.user_type === 'student' ? 'Start by discovering mentors!' : 'Wait for students to connect with you.'}
        </div>
      )}
    </div>
  );
};
