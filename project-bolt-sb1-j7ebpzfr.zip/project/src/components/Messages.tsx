import { useState, useEffect, useRef } from 'react';
import { supabase, Message, Profile } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { Send, MessageCircle } from 'lucide-react';

type ConnectionWithProfiles = {
  id: string;
  student: Profile;
  mentor: Profile;
};

export const Messages = () => {
  const { profile } = useAuth();
  const [connections, setConnections] = useState<ConnectionWithProfiles[]>([]);
  const [selectedConnection, setSelectedConnection] = useState<string | null>(null);
  const [messages, setMessages] = useState<(Message & { sender?: Profile })[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetchConnections();
  }, [profile]);

  useEffect(() => {
    if (selectedConnection) {
      fetchMessages();
      const subscription = supabase
        .channel(`messages:${selectedConnection}`)
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'messages',
            filter: `connection_id=eq.${selectedConnection}`,
          },
          () => {
            fetchMessages();
          }
        )
        .subscribe();

      return () => {
        subscription.unsubscribe();
      };
    }
  }, [selectedConnection]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const fetchConnections = async () => {
    if (!profile) return;

    try {
      const { data, error } = await supabase
        .from('mentorship_connections')
        .select(`
          id,
          student:profiles!mentorship_connections_student_id_fkey(*),
          mentor:profiles!mentorship_connections_mentor_id_fkey(*)
        `)
        .eq('status', 'active')
        .or(`student_id.eq.${profile.id},mentor_id.eq.${profile.id}`);

      if (error) throw error;
      setConnections(data || []);
      if (data && data.length > 0 && !selectedConnection) {
        setSelectedConnection(data[0].id);
      }
    } catch (error) {
      console.error('Error fetching connections:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchMessages = async () => {
    if (!selectedConnection) return;

    try {
      const { data, error } = await supabase
        .from('messages')
        .select(`
          *,
          sender:profiles(*)
        `)
        .eq('connection_id', selectedConnection)
        .order('created_at', { ascending: true });

      if (error) throw error;
      setMessages(data || []);

      const unreadMessages = data?.filter(m => !m.read && m.sender_id !== profile?.id) || [];
      if (unreadMessages.length > 0) {
        await supabase
          .from('messages')
          .update({ read: true })
          .in('id', unreadMessages.map(m => m.id));
      }
    } catch (error) {
      console.error('Error fetching messages:', error);
    }
  };

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !selectedConnection || !profile) return;

    try {
      const { error } = await supabase.from('messages').insert({
        connection_id: selectedConnection,
        sender_id: profile.id,
        content: newMessage.trim(),
      });

      if (error) throw error;
      setNewMessage('');
    } catch (error) {
      console.error('Error sending message:', error);
    }
  };

  const getOtherUser = (connection: ConnectionWithProfiles): Profile => {
    return profile?.user_type === 'student' ? connection.mentor : connection.student;
  };

  if (loading) {
    return <div className="text-center py-12 text-gray-600">Loading messages...</div>;
  }

  if (connections.length === 0) {
    return (
      <div className="text-center py-12">
        <MessageCircle className="w-16 h-16 text-gray-400 mx-auto mb-4" />
        <p className="text-gray-600">No active connections yet. Start by connecting with mentors!</p>
      </div>
    );
  }

  const currentConnection = connections.find(c => c.id === selectedConnection);

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold text-gray-900">Messages</h2>

      <div className="grid md:grid-cols-3 gap-4 h-[600px]">
        <div className="md:col-span-1 bg-white border border-gray-200 rounded-lg overflow-y-auto">
          <div className="p-4 border-b border-gray-200">
            <h3 className="font-semibold text-gray-900">Conversations</h3>
          </div>
          <div className="divide-y divide-gray-200">
            {connections.map((connection) => {
              const otherUser = getOtherUser(connection);
              return (
                <button
                  key={connection.id}
                  onClick={() => setSelectedConnection(connection.id)}
                  className={`w-full p-4 text-left hover:bg-gray-50 transition ${
                    selectedConnection === connection.id ? 'bg-blue-50' : ''
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-green-500 rounded-full flex items-center justify-center text-white font-bold flex-shrink-0">
                      {otherUser.full_name.charAt(0)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-gray-900 truncate">{otherUser.full_name}</p>
                      <p className="text-sm text-gray-600 truncate">{otherUser.career_field}</p>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        <div className="md:col-span-2 bg-white border border-gray-200 rounded-lg flex flex-col">
          {currentConnection && (
            <>
              <div className="p-4 border-b border-gray-200">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-green-500 rounded-full flex items-center justify-center text-white font-bold">
                    {getOtherUser(currentConnection).full_name.charAt(0)}
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">
                      {getOtherUser(currentConnection).full_name}
                    </h3>
                    <p className="text-sm text-gray-600">
                      {getOtherUser(currentConnection).career_field}
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {messages.map((message) => {
                  const isOwn = message.sender_id === profile?.id;
                  return (
                    <div
                      key={message.id}
                      className={`flex ${isOwn ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-[70%] rounded-2xl px-4 py-2 ${
                          isOwn
                            ? 'bg-blue-600 text-white'
                            : 'bg-gray-100 text-gray-900'
                        }`}
                      >
                        <p className="text-sm break-words">{message.content}</p>
                        <p className={`text-xs mt-1 ${isOwn ? 'text-blue-100' : 'text-gray-500'}`}>
                          {new Date(message.created_at).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </p>
                      </div>
                    </div>
                  );
                })}
                <div ref={messagesEndRef} />
              </div>

              <form onSubmit={sendMessage} className="p-4 border-t border-gray-200">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder="Type your message..."
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                  />
                  <button
                    type="submit"
                    disabled={!newMessage.trim()}
                    className="bg-blue-600 hover:bg-blue-700 text-white p-2 rounded-lg transition disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <Send className="w-5 h-5" />
                  </button>
                </div>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
